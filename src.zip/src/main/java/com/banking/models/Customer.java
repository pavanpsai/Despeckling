package com.banking.models;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.List;
//import Models.Account;

@Entity
public class Customer {

    @Id
    private long customerId;

    private String firstName;

    private String lastName;

    private String email;

    private long phoneNumber;

    private int age;

    private String address;

//    private Account account;

    public Customer() {
    }

    public Customer(long customerId, String firstName, String lastName, String email, long phoneNumber, int age, String address) {
        this.customerId = customerId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.age = age;
        this.address = address;
    }

//    public Customer(long customerId, String firstName, String lastName, String email, long phoneNumber, int age, String address) {
//        this.customerId = customerId;
//        this.firstName = firstName;
//        this.lastName = lastName;
//        this.email = email;
//        this.phoneNumber = phoneNumber;
//        this.age = age;
//        this.address = address;
////        this.account = account;
//    }

    public long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(long customerId) {
        this.customerId = customerId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

//    public Account getAccountList() {
//        return account;
//    }
//
//    public void setAccountList(Account account) {
//        this.account = account;
//    }
}
