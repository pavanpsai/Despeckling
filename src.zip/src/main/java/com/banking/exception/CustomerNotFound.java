package com.banking.exception;

public class CustomerNotFound {
}
