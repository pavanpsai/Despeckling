package com.banking.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.banking.exception.CustomerAlreadyExist;

@Controller
public class GlobalExceptionHandler {
    @ExceptionHandler(value = CustomerAlreadyExist.class)
    public ResponseEntity<String> customerAlreadyException(CustomerAlreadyExist customerAlreadyExist){
        return new ResponseEntity<String>("Customer Already Exists", HttpStatus.CONFLICT);
    }
}

