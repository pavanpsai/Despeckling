package com.banking.exception;

public class CustomerAlreadyExist extends Exception{

    private String message;

    public CustomerAlreadyExist() {
    }

    public CustomerAlreadyExist(String message) {
        super();
        this.message = message;
    }
}
