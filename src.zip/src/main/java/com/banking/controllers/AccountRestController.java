package com.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.banking.models.Account;
import com.banking.repositories.AccountRepository;
import com.banking.services.AccountServiceImpl;

import java.util.List;

@RestController
@RequestMapping("api/v1")
public class AccountRestController {

    private AccountServiceImpl accountService;
    private AccountRepository accountRepository;

    @Autowired
    public AccountRestController(AccountServiceImpl accountService) {
        this.accountService = accountService;
    }

    @PostMapping("/account")
    public ResponseEntity<Account> addAccount(@RequestBody Account account){
        Account accountObj = accountService.addAccount(account);
        return new ResponseEntity<Account>(accountObj, HttpStatus.CREATED);
    }

    @GetMapping("/accounts")
    public ResponseEntity<List<Account>> getAllAccounts(){
        return new ResponseEntity<List<Account>>(accountService.getAllAccounts(),HttpStatus.OK);
    }

    @PutMapping("/account")
    public ResponseEntity<Account> updateAccount(@RequestBody Account account){
       Account accountObjUpdate = accountService.updateAccount(account);
        return new ResponseEntity<Account>(accountObjUpdate,HttpStatus.ACCEPTED);
    }

    @GetMapping("/account/id/{id}")
    public ResponseEntity<Account> getAccountById(@PathVariable long accountId) {
        return new ResponseEntity<Account>((Account) accountService.getAccountById(accountId),HttpStatus.OK);
    }

    @DeleteMapping("account/{id}")
    public ResponseEntity deleteAccount(@PathVariable long accountId){
        accountService.deleteAccount(accountId);
        return new ResponseEntity(HttpStatus.GONE);
    }

}
