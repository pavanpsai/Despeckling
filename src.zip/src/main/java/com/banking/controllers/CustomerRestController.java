package com.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.banking.exception.CustomerAlreadyExist;
import com.banking.models.Customer;
import com.banking.repositories.CustomerRepository;
import com.banking.services.CustomerServiceImpl;

import java.util.List;

@RestController
@RequestMapping("api/v1")
public class CustomerRestController {

    private CustomerServiceImpl customerService;
    private CustomerRepository customerRepository;

    @Autowired
    public CustomerRestController(CustomerServiceImpl customerService) {
        this.customerService = customerService;
    }

    @PostMapping("/customer")
    public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer) throws CustomerAlreadyExist {
        Customer customerObj = customerService.addCustomer(customer);
        return new ResponseEntity<Customer>(customerObj, HttpStatus.CREATED);
    }

    @GetMapping("/customers")
    public ResponseEntity<List<Customer>> getAllCustomers(){
        return new ResponseEntity<List<Customer>>(customerService.getAllCustomers(),HttpStatus.OK);
    }

    @PutMapping("/customer")
    public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer ){
       Customer customerObjToUpdate = customerService.updateCustomer(customer);
        return new ResponseEntity<Customer>(customerObjToUpdate,HttpStatus.ACCEPTED);
    }

    @GetMapping("/customers/id/{id}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable long customerId) {
        return new ResponseEntity<Customer>((Customer) customerService.getCustomerById(customerId),HttpStatus.OK);
    }

    @DeleteMapping("customer/{id}")
    public ResponseEntity deleteCustomer(@PathVariable long customerId){
        customerService.deleteCustomer(customerId);
            return new ResponseEntity(HttpStatus.GONE);
        }
}


