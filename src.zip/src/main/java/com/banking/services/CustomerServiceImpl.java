package com.banking.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.banking.exception.CustomerAlreadyExist;
import com.banking.models.Customer;
import com.banking.repositories.CustomerRepository;
import com.banking.services.CustomerService;

import java.util.List;

@Component
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public Customer addCustomer(Customer customer)throws CustomerAlreadyExist {
        if (customerRepository.existsById(customer.getCustomerId())){
            throw new  CustomerAlreadyExist();
        }
        else{
            Customer customerObj = customerRepository.save(customer);
            return customerObj;
        }
    }

    public List<Customer> getAllCustomers() {
        return (List<Customer>) customerRepository.findAll();
    }

    public Customer updateCustomer(Customer customer) {
        Customer customerObjToUpdate = customerRepository.save(customer);
        return customerObjToUpdate;
    }

    public Customer getCustomerById(long customerId) {
        return customerRepository.findById(customerId);
    }

    public void deleteCustomer(long customerId) {
       Customer customerDeleteObj = customerRepository.findById(customerId);
        customerRepository.delete(customerDeleteObj);
    }
}
