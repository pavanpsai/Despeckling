package com.banking.services;

import java.util.List;

import com.banking.exception.CustomerAlreadyExist;
import com.banking.models.Customer;

public interface CustomerService {

    Customer addCustomer(Customer customer)throws CustomerAlreadyExist;

    List<Customer> getAllCustomers();

    Customer getCustomerById(long customerId);

     void deleteCustomer(long customerId);

    Customer updateCustomer(Customer customer);
}
