package com.banking.services;

import java.util.List;

import com.banking.models.Account;
import com.banking.models.Customer;

public interface AccountService {

    Account addAccount(Account account);

    List<Account> getAllAccounts();

    Account getAccountById(long accountId);

    void deleteAccount(long accountId);

    Account updateAccount(Account account);
}
