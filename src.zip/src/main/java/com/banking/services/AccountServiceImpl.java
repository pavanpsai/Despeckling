package com.banking.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.banking.models.Account;
import com.banking.repositories.AccountRepository;

import java.util.List;

@Component
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountRepository accountRepository;

    public Account addAccount(Account account) {
        Account accountObj = accountRepository.save(account);
      return  accountObj;
    }

    public List<Account> getAllAccounts() {
        return (List<Account>) accountRepository.findAll();
    }

    public Account updateAccount(Account account) {
        Account accountObjToUpdate = accountRepository.save(account);
        return accountObjToUpdate;
    }

    public void deleteAccount(long accountId) {
        Account accountDelete = accountRepository.findById(accountId);
        accountRepository.delete(accountDelete);
    }

    public Account getAccountById(long accountId) {
        return accountRepository.findById(accountId);
    }
}
